GitHub readme profile:
It's simple to create this, just create MTrajK repo (home repo, for web site) and add a readme file in it.

https://www.aboutmonica.com/blog/how-to-create-a-github-profile-readme
https://www.reddit.com/r/coding/comments/hsvnrv/how_to_create_a_github_profile_readme


- Auto update
https://github.com/jamesgeorge007/github-activity-readme
https://www.reddit.com/r/javascript/comments/hu3j6w/heres_a_github_action_that_would_update_readme/
https://github.com/jamesgeorge007


Simple readmeS:
https://github.com/sini6a


Interesting readmeS:
https://github.com/jlengstorf
https://twitter.com/sudo_overflow/status/1281146411736694784
https://github.com/simonw
https://github.com/terrytangyuan